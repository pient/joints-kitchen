#!/usr/bin/env bash

# 切换目录
cd /Users/liuyi/CodeRepo/work/hdt/nodehdt

# 运行构建
npm run build

# 打包
slc build --pack

# 上传包
scp ../hdt-0.0.1.tgz nodehdt@10.255.13.56:/opt/app/nodeapps/nodehdt/packages



